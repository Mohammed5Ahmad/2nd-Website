/*let gre =prompt("ENTER THE PASSWORD")
if (gre==885998)
{
alert("ACCESS APPROVED")
}
else {


while (gre != "885998") {
  gre = prompt("TRY AGAIN!");
}

alert("ACCESS APPROVED");
 
   
 } 

*/
//let result=confirm("Do Want To Entet?")
//if(result){
// alert("YES")
//}
//else{
// alert("NO")
//}
//let result = confirm("هل أنت متأكد أنك تريد المتابعة؟");

/*if (result) {
  alert("تم الاختيار: نعم ✅");
}*/

function toggleSidebar() {
  document.getElementById("sidebar").classList.toggle("open");
}
